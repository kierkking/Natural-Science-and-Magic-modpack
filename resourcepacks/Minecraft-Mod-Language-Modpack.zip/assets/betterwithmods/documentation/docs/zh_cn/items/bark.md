![Bark](item:betterwithmods:bark)

通过使用斧子加工或者使用[螺杆锯](../blocks/saw.md)切割将树皮从原木上剥离出来。
树皮可以用做燃料或作为[鞣制皮革](tanned_leather.md)的原料。